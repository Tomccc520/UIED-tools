export declare const fetchWebInfo: (data: WebInfoReqData) => any;
