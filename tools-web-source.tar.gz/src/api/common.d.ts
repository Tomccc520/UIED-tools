export interface ResponseData {
    code: number;
    message: string;
}
