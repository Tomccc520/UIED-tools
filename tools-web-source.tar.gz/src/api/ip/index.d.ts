export declare const getIp: (data: IpReqData) => any;
