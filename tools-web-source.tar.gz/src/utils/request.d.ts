declare let request: import("axios").AxiosInstance;
export default request;
