<script setup lang="ts">
/**
 * @file Banner.vue
 * @description 广告横幅组件，用于展示广告内容
 * @createDate 2024-03-21
 */

// 导入需要的组件和接口
import { ref } from 'vue'
import { Close } from '@element-plus/icons-vue'  // 导入Close图标

// 导入图片资源
import banner1 from '@/assets/banner/banner1.jpg'
import banner2 from '@/assets/banner/banner2.jpg'

// 广告数据
const bannerList = ref([
  {
    id: 1,
    image: banner1,
    link: 'https://askmany.cn/login?i=bd8ce9a1'
  },
  {
    id: 2,
    image: banner2,
    link: 'https://www.uied.cn/'
  }
])

// 是否显示广告
const showBanner = ref(true)

// 关闭广告
const closeBanner = () => {
  showBanner.value = false
}
</script>

<template>
  <div v-if="showBanner" class="banner-container w-full relative">
    <!-- 轮播广告 -->
    <el-carousel height="50px" :interval="5000" arrow="hover" class="w-full">
      <el-carousel-item v-for="item in bannerList" :key="item.id">
        <a :href="item.link" target="_blank" class="block w-full h-full relative">
          <img :src="item.image" :alt="item.title" class="w-full h-full object-cover">
        </a>
      </el-carousel-item>
    </el-carousel>

    <!-- 关闭按钮 -->
    <el-button class="close-btn !absolute !right-2 !top-2" circle size="small" @click="closeBanner">
      <el-icon>
        <Close />
      </el-icon>
    </el-button>
  </div>
</template>

<style scoped>
.banner-container {
  border-radius: 8px;
  overflow: hidden;
  max-height: 50px;
}

/* 自定义轮播图样式 */
:deep(.el-carousel__item) {
  background: #f5f7fa;
}

:deep(.el-carousel__arrow) {
  background-color: rgba(0, 0, 0, 0.3);
}

:deep(.el-carousel__arrow:hover) {
  background-color: rgba(0, 0, 0, 0.6);
}

.close-btn {
  z-index: 10;
  opacity: 0.8;
  transition: opacity 0.3s;
  background-color: rgba(255, 255, 255, 0.8);
}

.close-btn:hover {
  opacity: 1;
  background-color: #fff;
}

/* 文字显示区域样式 */
.line-clamp-2 {
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
</style>
