/**
* @file RuaAvatar.vue
* @description 摸头GIF生成工具，支持上传图片生成摸头GIF
* @author UIED技术团队
* @copyright UIED技术团队 (https://fsuied.com)
* @createDate 2025-1-12
* @lastEditor UIED技术团队
* @lastEditTime 2025-1-12 01:01
*
* 功能特性：
* 1. 支持图片上传生成摸头GIF
* 2. 图片格式限制：支持JPG/PNG格式，文件大小不超过10MB
* 3. 实时预览功能
* 4. 一键下载生成的GIF
* 5. 优雅的加载动画和交互效果
* 6. 响应式布局适配
*
* API: https://api.52vmy.cn/api/avatar/rua
*/

<template>
  <div class="min-h-screen">
    <div class="mx-auto">
      <!-- 维护提示 -->
      <div class="bg-white border border-gray-200 rounded-lg p-6 mb-4">
        <div class="flex items-center p-4 bg-yellow-50 border-l-4 border-yellow-400 rounded-r-lg">
          <div class="flex-shrink-0">
            <svg class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
              <path fill-rule="evenodd"
                d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z"
                clip-rule="evenodd" />
            </svg>
          </div>
          <div class="ml-3">
            <p class="text-sm text-yellow-700">
              该功能正在维护中，暂时无法使用。我们正在努力修复，请稍后再试。
            </p>
          </div>
        </div>
      </div>

      <!-- 主要内容区域 -->
      <div class="bg-white rounded-xl p-8 mb-4 shadow-sm opacity-50 pointer-events-none">
        <div class="text-center mb-8 relative">
          <h2 class="text-4xl font-bold mb-3 relative inline-flex flex-col items-center">
            <div class="relative px-12">
              <span class="text-gray-800 hover:text-gray-600 transition-colors duration-300 cursor-pointer"
                @click="handleTitleClick">摸头GIF生成器</span>
            </div>
          </h2>
          <p class="text-gray-500 text-sm mt-6">上传图片即可生成可爱的摸头GIF</p>
          <p class="text-gray-400 text-xs mt-2">支持 JPG/PNG 格式，文件大小不超过 10MB</p>
        </div>

        <!-- 图片预览区域 -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <!-- 原图预览 -->
          <div class="bg-white border border-gray-200 rounded-lg p-6 flex justify-center items-center"
            style="min-height: 300px;">
            <div class="avatar-preview" v-loading="loading">
              <img v-if="originalUrl" :src="originalUrl" alt="原始照片" class="avatar-image rounded-lg" />
              <div v-else class="placeholder">
                <el-icon class="text-4xl text-gray-300">
                  <Picture />
                </el-icon>
                <div class="text-gray-400 mt-2">原始照片</div>
              </div>
            </div>
          </div>

          <!-- GIF预览 -->
          <div class="bg-white border border-gray-200 rounded-lg p-6 flex justify-center items-center"
            style="min-height: 300px;">
            <div class="avatar-preview" v-loading="loading">
              <template v-if="convertedUrl">
                <img :src="convertedUrl" class="avatar-image rounded-lg" alt="GIF预览"
                  @error="(e) => { console.error('Image load error:', e); }" />
              </template>
              <template v-else-if="loading">
                <div class="flex flex-col items-center justify-center">
                  <div class="w-12 h-12 rounded-full border-4 border-blue-100 border-t-blue-500 animate-spin"></div>
                  <span class="mt-4 text-gray-400">生成中...</span>
                </div>
              </template>
              <template v-else>
                <div class="placeholder">
                  <el-icon class="text-4xl text-gray-300">
                    <Picture />
                  </el-icon>
                  <div class="text-gray-400 mt-2">摸头GIF</div>
                </div>
              </template>
            </div>
          </div>
        </div>

        <div class="flex justify-center gap-4">
          <input ref="fileInput" type="file" accept=".jpg,.jpeg,.png" class="hidden" @change="handleFileUpload">
          <button @click="triggerFileInput"
            class="inline-flex items-center px-6 py-2.5 bg-blue-500 hover:bg-blue-600 text-white rounded-lg text-sm transition-colors duration-300">
            <svg class="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
              stroke-linecap="round" stroke-linejoin="round">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
              <polyline points="17 8 12 3 7 8"></polyline>
              <line x1="12" y1="3" x2="12" y2="15"></line>
            </svg>
            上传图片
          </button>
          <button @click="downloadGif" :disabled="!convertedUrl"
            class="inline-flex items-center px-6 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg text-sm transition-colors duration-300 disabled:opacity-50 disabled:cursor-not-allowed">
            <svg class="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
              stroke-linecap="round" stroke-linejoin="round">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
              <polyline points="7 10 12 15 17 10"></polyline>
              <line x1="12" y1="15" x2="12" y2="3"></line>
            </svg>
            下载GIF
          </button>
        </div>
      </div>

      <!-- 工具推荐 -->
      <ToolsRecommend :currentPath="route.path" />

      <!-- 提示信息 -->
      <div v-if="showToast"
        class="fixed top-4 right-4 px-4 py-2 rounded-lg text-sm text-white shadow-lg transition-all duration-300"
        :class="toastType === 'success' ? 'bg-green-500' : 'bg-red-500'">
        {{ toastMessage }}
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, nextTick } from '@vue/runtime-core'
import { useRoute } from 'vue-router'
import ToolsRecommend from '@/components/Common/ToolsRecommend.vue'
import { Picture } from '@element-plus/icons-vue'

const route = useRoute()
const fileInput = ref<HTMLInputElement | null>(null)
const originalUrl = ref('')
const convertedUrl = ref('')
const loading = ref(false)
const showToast = ref(false)
const toastMessage = ref('')
const toastType = ref('success')

// 显示消息
const showMessage = (message: string, type: 'success' | 'error') => {
  toastMessage.value = message
  toastType.value = type
  showToast.value = true
  setTimeout(() => {
    showToast.value = false
  }, 2000)
}

// 验证文件格式和大小
const isValidImageFile = (file: File): boolean => {
  const validTypes = ['image/jpeg', 'image/png']
  const maxSize = 10 * 1024 * 1024 // 10MB

  if (!validTypes.includes(file.type)) {
    showMessage('请上传 JPG 或 PNG 格式的图片', 'error')
    return false
  }

  if (file.size > maxSize) {
    showMessage('图片大小不能超过 10MB', 'error')
    return false
  }

  return true
}

// 触发文件选择
const triggerFileInput = () => {
  fileInput.value?.click()
}

// 标题点击效果
const handleTitleClick = () => {
  triggerFileInput()

  // 播放点击波纹动画
  const ripple = document.createElement('div')
  ripple.className = 'absolute bg-blue-500/20 rounded-full animate-ripple'
  ripple.style.width = '100px'
  ripple.style.height = '100px'
  ripple.style.left = '50%'
  ripple.style.top = '50%'
  ripple.style.transform = 'translate(-50%, -50%)'

  const title = document.querySelector('.group')
  if (title) {
    title.appendChild(ripple)
    setTimeout(() => ripple.remove(), 1000)
  }
}

// 处理文件上传
const handleFileUpload = async (event: Event) => {
  const input = event.target as HTMLInputElement
  const file = input.files?.[0]

  if (!file || !isValidImageFile(file)) return

  // 显示原图预览
  const reader = new FileReader()
  reader.onload = async (e) => {
    originalUrl.value = e.target?.result as string

    // 开始生成GIF
    loading.value = true
    if (convertedUrl.value) {
      URL.revokeObjectURL(convertedUrl.value)
      convertedUrl.value = ''
    }

    try {
      const formData = new FormData()
      formData.append('file', file)  // 直接发送文件而不是base64

      const url = '/api/avath/rua'
      const result = await fetch(url, {
        method: 'POST',
        body: formData,
        headers: {
          'Accept': 'image/gif,image/*'
        }
      })

      // 检查响应类型
      const contentType = result.headers.get('content-type')
      console.log('Response content type:', contentType)

      if (!result.ok) {
        const errorText = await result.text()
        console.error('API Error:', {
          status: result.status,
          statusText: result.statusText,
          response: errorText
        })
        throw new Error(`转换失败 (${result.status}): ${result.statusText}`)
      }

      // 如果返回的是HTML，说明可能是错误页面
      if (contentType?.includes('text/html')) {
        const errorText = await result.text()
        console.error('API returned HTML:', errorText)
        throw new Error('API服务异常，请稍后重试')
      }

      const gifBlob = await result.blob()
      if (gifBlob.size === 0) {
        throw new Error('生成的GIF为空，请重试')
      }

      await nextTick()
      const gifUrl = URL.createObjectURL(gifBlob)
      convertedUrl.value = gifUrl

      showMessage('生成成功', 'success')
    } catch (error) {
      console.error('Error:', error)
      showMessage(error instanceof Error ? error.message : '转换失败，请重试', 'error')
      if (convertedUrl.value) {
        URL.revokeObjectURL(convertedUrl.value)
        convertedUrl.value = ''
      }
    } finally {
      loading.value = false
      input.value = ''
    }
  }
  reader.readAsDataURL(file)
}

// 下载GIF
const downloadGif = async () => {
  if (!convertedUrl.value) {
    showMessage('请先生成GIF', 'error')
    return
  }

  try {
    const response = await fetch(convertedUrl.value)
    const blob = await response.blob()
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'rua.gif'
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    window.URL.revokeObjectURL(url)
    showMessage('下载成功', 'success')
  } catch (error) {
    showMessage('下载失败，请重试', 'error')
  }
}
</script>

<style scoped>
.avatar-preview {
  width: 200px;
  height: 200px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.avatar-image {
  max-width: 100%;
  max-height: 100%;
  object-fit: contain;
  transition: transform 0.3s ease;
}

.avatar-image:hover {
  transform: scale(1.05);
}

.placeholder {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

@keyframes ripple {
  from {
    transform: translate(-50%, -50%) scale(0);
    opacity: 1;
  }

  to {
    transform: translate(-50%, -50%) scale(2);
    opacity: 0;
  }
}

.animate-ripple {
  animation: ripple 1s ease-out forwards;
}

/* 响应式调整 */
@media (max-width: 640px) {
  .avatar-preview {
    width: 150px;
    height: 150px;
  }
}
</style>
