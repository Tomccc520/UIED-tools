declare const _default: import("vue").DefineComponent<{
    title: StringConstructor;
    subtitle: StringConstructor;
    id: NumberConstructor;
}, {}, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    title: StringConstructor;
    subtitle: StringConstructor;
    id: NumberConstructor;
}>>, {}, {}>;
export default _default;
