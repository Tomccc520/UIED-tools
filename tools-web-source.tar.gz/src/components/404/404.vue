<template>
  <div>
    <el-empty :image-size="200" />
  </div>
</template>

<script setup lang="ts">

</script>

<style scoped lang="scss">
</style>