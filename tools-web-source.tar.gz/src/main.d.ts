import 'virtual:svg-icons-register';
import './styles/tailwind.css';
import 'element-plus/dist/index.css';
import 'default-passive-events';
