declare module 'vue' {
  export * from '@vue/runtime-core'
  export * from '@vue/runtime-dom'
}
