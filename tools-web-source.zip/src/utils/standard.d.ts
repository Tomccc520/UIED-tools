/**
 * sleep
 * @param ms
 * @returns
 */
export declare function sleep(ms: number): Promise<void>;
