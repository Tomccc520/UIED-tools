import { createPinia } from 'pinia'

//创建大仓库
let pinia = createPinia()

//对外暴露: 入口文件引入
export default pinia