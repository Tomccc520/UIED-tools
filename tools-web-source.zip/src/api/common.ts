//请求响应的公共数据
export interface ResponseData {
  code: number,
  message: string,
}