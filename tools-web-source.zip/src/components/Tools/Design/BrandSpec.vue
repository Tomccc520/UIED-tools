<!-- 品牌设计规范工具 -->
<template>
  <div class="brand-spec flex flex-col items-center justify-center min-h-[400px] text-center">
    <div class="text-gray-500">
      <i class="fas fa-tools text-6xl mb-4"></i>
      <h2 class="text-2xl font-bold mb-2">功能开发中</h2>
      <p class="text-gray-400">该功能正在开发中，敬请期待...</p>
    </div>
  </div>
</template>

<script setup lang="ts">
// 开发中，暂无脚本逻辑
</script>

<style scoped>
.brand-spec {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}
</style>
