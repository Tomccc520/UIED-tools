declare const _default: import("vue").DefineComponent<{}, {
    throwDice: () => Promise<void>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    throwEnd: (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{}>> & {
    onThrowEnd?: ((...args: any[]) => any) | undefined;
}, {}, {}>;
export default _default;
